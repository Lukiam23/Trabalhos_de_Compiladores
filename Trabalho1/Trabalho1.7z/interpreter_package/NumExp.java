package interpreter_package;

public class NumExp extends Exp {
    public int num;

    public NumExp(int n) {
        num = n;
    }
}
