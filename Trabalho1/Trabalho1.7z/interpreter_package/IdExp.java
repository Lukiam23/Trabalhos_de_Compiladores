package interpreter_package;

public class IdExp extends Exp {
    public String id;

    public IdExp(String i) {
        id = i;
    }
}
