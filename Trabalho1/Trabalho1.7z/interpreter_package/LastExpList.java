package interpreter_package;

public class LastExpList extends ExpList { 
    public Exp head; 
    public LastExpList(Exp h) {
        head=h;
    }
}