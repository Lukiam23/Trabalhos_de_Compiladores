package interpreter_package;

public class EseqExp extends Exp {
    public Stm stm;
    public Exp exp;

    public EseqExp(Stm s, Exp e) {
        stm = s;
        exp = e;
    }
}
